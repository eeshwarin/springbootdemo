package com.example;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.web.bind.annotation.*;

@RestController
//@EnableAutoConfiguration
@SpringBootApplication //same as @Configuration @EnableAutoConfiguration @ComponentScan
public class Example {

	@RequestMapping("/")
	String home() {
		return "Hello World!";
	}
	
	@RequestMapping("/name")
	String getName() {
		return "Hello!";
	}

	/*public static void main(String[] args) throws Exception {
		SpringApplication.run(Example.class, args);

	}*/

}
//http://docs.spring.io/spring-boot/docs/current/reference/html/getting-started-first-application.html
//mvn dependency:tree
//mvn spring-boot:run
//mvn package   (will create executable file in target folder with .jar name)
//java -jar target/springbootdemo-0.0.1-SNAPSHOT.jar (this will execute the program from executable jar file and it will start the tomcat at 8080
//http://localhost:8080/ 
//http://localhost:8080/name
//ctr+c to exit the server
//http://javabeat.net/spring-boot-spring-mvc/
